pintos
======

Sam Acuna - sa29589
Cindy Jaimez - cj8887
Ji Won Min - jm68874